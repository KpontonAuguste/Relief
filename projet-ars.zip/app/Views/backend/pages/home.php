<?= $this->extend('backend/layout/pages-layout') ?>
<?= $this->section('content') ?>
<h2> Bonjour et bienvenue </h2>
<?= $this->endSection() ?>